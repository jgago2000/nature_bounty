# Send Friend Functional Tests

The Functional Test Module for **Magento Send Friend** module.
