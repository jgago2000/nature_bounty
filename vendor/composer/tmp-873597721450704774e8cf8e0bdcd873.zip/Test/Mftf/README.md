# New Relic Reporting Functional Tests

The Functional Test Module for **Magento New Relic Reporting** module.
