## Magento_InventoryAdvancedCheckout

## Overview

The Magento_InventoryAdvancedCheckout module adds multi-sourcing capabilities to the AdvancedCheckout module allowing Order By SKU feature to work correctly with multiple inventory sources enabled.