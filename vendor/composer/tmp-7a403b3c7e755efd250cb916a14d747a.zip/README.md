The Magento_InventoryCatalogSearchBundleProduct module adds multi-sourcing capabilities to the Magento's CatalogSearch module
