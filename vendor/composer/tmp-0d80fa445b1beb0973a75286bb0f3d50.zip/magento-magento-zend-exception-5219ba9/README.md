INFORMATION
===================

This is a fork of "Zend_Exception" module from Zend Framework 1.12.16 Release

PURPOSE
---------------------------
This package is a part of the Zend Framework 1. Component was separated and put into its own composer package.

LICENSE
=======

The files in this archive are released under the Zend Framework license.
You can find a copy of this license in [LICENSE.txt](LICENSE.txt).
